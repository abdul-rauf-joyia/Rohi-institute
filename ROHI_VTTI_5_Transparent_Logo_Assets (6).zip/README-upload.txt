ROHI VTTI — five transparent logo assets

Upload all five PNG files in this folder to the ROOT of:
https://github.com/abdul-rauf-joyia/Rohi-institute

Keep the filenames exactly as shown. The website's logo row is configured to use:
01-rohi-vtti.png
02-pakistan-national-emblem.png
03-government-of-pakistan.png
04-navttc.png
05-prime-ministers-youth-programme.png

Order: ROHI VTTI, Pakistan National Emblem, Government of Pakistan, NAVTTC,
Prime Minister's Youth Programme.

Four logos are from the supplied 4K ZIP. The PM Youth Programme logo was supplied
as a 300 x 236 image and enlarged to 4096 px wide with transparency preserved;
upscaling does not restore detail absent from the small original.
